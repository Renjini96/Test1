package com.example.weathermanagement.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.weathermanagement.Entity.WeatherEntity;
import com.example.weathermanagement.dto.WeatherDto;
import com.example.weathermanagement.model.WeatherModel;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class WeatherDao {
	@PersistenceContext
	private EntityManager em;
	
	private ObjectMapper objectMapper;
	
	public WeatherDto addWeather(WeatherModel weatherModel) {
		em.merge(weatherModel);
		WeatherDto weatherDto = objectMapper.convertValue(weatherModel, WeatherDto.class);
		return weatherDto;
	}
	
	public List<WeatherDto> retrieveAllMeasurements(String fromDate, String toDate){
		String hql="Select * from WeatherEntity where timestamp >= :FROM and timestamp <= :TO";
		em.setProperty("FROM", fromDate);
		em.setProperty("TO", toDate);
		List<WeatherEntity> we = em.createQuery(hql, WeatherEntity.class).getResultList();
		List<WeatherDto> weatherDtos = objectMapper.findModules().addAll(we).getClass();
	}
	
	

}
