package com.example.weathermanagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.weathermanagement.dao.WeatherDao;
import com.example.weathermanagement.dto.WeatherDto;
import com.example.weathermanagement.model.WeatherModel;

import jakarta.transaction.Transactional;

@Service
public class weatherService {

	String fromDate = "01/01/2024";
	String toDate = "01/07/2024";
	@Autowired
	private WeatherDao weatherDao;

	@Transactional
	public WeatherDto addWeather(WeatherModel weatherModel) {

		WeatherDto weatherDto = weatherDao.addWeather(weatherModel);
		return weatherDto;

	}

	public List<WeatherDto> reteiveAllMeasuremets() {

		List<WeatherDto> weatherDtos = weatherDao.retrieveAllMeasurements(fromDate, toDate);
		return weatherDtos;

	}

	public List avgMinMax() {
		float avg,sum=0,max=0,min=0 ;
		List<WeatherDto> weatherDtos = weatherDao.retrieveAllMeasurements(fromDate, toDate);		
		long length = weatherDtos.size();
		for(WeatherDto weDto :weatherDtos ) {
			sum = sum+weDto.getTemperature();
			if(max<weDto.getTemperature())
				max=weDto.getTemperature();
			
		}
		avg=sum/length;
		List le = new ArrayList();
		le.add(avg);
		le.add(max);
		return le;
	}
}
