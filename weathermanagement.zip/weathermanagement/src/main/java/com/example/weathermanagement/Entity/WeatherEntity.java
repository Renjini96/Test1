package com.example.weathermanagement.Entity;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table
public class WeatherEntity {
	@Id
	private long id;
	private long stationId;
	private Date timestamp;
	private float temperature;
	private float humidity;
	private float windSpeed;
}
