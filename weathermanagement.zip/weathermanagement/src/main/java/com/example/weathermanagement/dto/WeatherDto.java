package com.example.weathermanagement.dto;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class WeatherDto {
	public float getTemperature() {
		return temperature;
	}
	public void setTemperature(float temperature) {
		this.temperature = temperature;
	}
	private long id;
	private long stationId;
	private Date timestamp;
	private float temperature;
	private float humidity;
	private float windSpeed;
}
