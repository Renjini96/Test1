package com.example.weathermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.weathermanagement.dto.WeatherDto;
import com.example.weathermanagement.model.WeatherModel;
import com.example.weathermanagement.service.weatherService;

@Controller
public class weatherController {
	@Autowired
	private weatherService weaService;

	@PostMapping("/api/measurements")
	public WeatherDto addWeather(@RequestBody WeatherModel weatherModel) {
		WeatherDto weatherDto = weaService.addWeather(weatherModel);
		return weatherDto;
	}

	@GetMapping("/api/measurements")
	public List<WeatherDto> retrieveAllMeasurementswithdateRange() {

		List<WeatherDto> weatherDtos = weaService.reteiveAllMeasuremets();
		return weatherDtos;

	}
	
	@GetMapping("/api/measurements/stats")
	public List avgMinMax() {
		List avgMinMaxValues = weaService.avgMinMax();
		return avgMinMaxValues;
	}

}
