package com.example.weathermanagement.model;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class WeatherModel {
	
	private long id;
	private long stationId;
	private Date timestamp;
	private float temperature;
	private float humidity;
	private float windSpeed;	
	

}
