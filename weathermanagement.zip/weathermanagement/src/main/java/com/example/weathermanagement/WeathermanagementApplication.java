package com.example.weathermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeathermanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeathermanagementApplication.class, args);
	}

}
