package com.example.weathermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeathermanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
